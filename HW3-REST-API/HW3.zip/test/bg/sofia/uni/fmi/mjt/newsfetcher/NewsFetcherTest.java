package bg.sofia.uni.fmi.mjt.newsfetcher;

import bg.sofia.uni.fmi.mjt.article.Article;
import bg.sofia.uni.fmi.mjt.client.NewsHTTPClient;
import bg.sofia.uni.fmi.mjt.exceptions.InvalidRequestParameterException;
import bg.sofia.uni.fmi.mjt.newrequest.NewsRequest;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

//Credits to: https://github.com/w1nston19/Java/tree/main/bg/uni/sofia/fmi/mjt
// I have used these tests as an example

class NewsFetcherTest {
    private static final String myResponse = "{\"status\":\"success\",\"totalResults\":3,\"data\":" +
            "[" +
            "{\"source\":{\"id\":\"src1\",\"name\":\"SourceOne\"}," +
            "\"author\":\"Jane Doe\",\"headline\":\"Breaking News 1\"," +
            "\"summary\":\"Summary of news 1\",\"publishTime\":\"2025-01-20T12:00:00Z\"," +
            "\"content\":\"Full content of news 1\"}," +
            "{\"source\":{\"id\":\"src2\",\"name\":\"SourceTwo\"},\"author\":\"John Smith\",\"headline\":\"Breaking News 2\"," +
            "\"summary\":\"Summary of news 2\",\"publishTime\":\"2025-01-20T13:00:00Z\"," +
            "\"content\":\"Full content of news 2\"}," +
            "{\"source\":{\"id\":\"src3\",\"name\":\"SourceThree\"},\"author\":\"Alex Johnson\",\"headline\":\"Breaking News 3\"," +
            "\"summary\":\"Summary of news 3\",\"publishTime\":\"2025-01-20T14:00:00Z\"," +
            "\"content\":\"Full content of news 3\"}]}";

    private static final HttpClient mockHttpClient = Mockito.mock(HttpClient.class);
    private static final CompletableFuture<HttpResponse<String>> mockResponse =
            Mockito.mock(CompletableFuture.class);

    private static final NewsFetcher testedFetcher = new NewsFetcher();

    static {
        testedFetcher.setClient(new NewsHTTPClient(mockHttpClient));

        try {
            HttpResponse<String> httpResponseMock = Mockito.mock(HttpResponse.class);
            when(httpResponseMock.statusCode()).thenReturn(200);
            when(httpResponseMock.body()).thenReturn(myResponse);
            when(mockResponse.get()).thenReturn(httpResponseMock);
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }

        when(mockHttpClient.sendAsync(any(HttpRequest.class), any(HttpResponse.BodyHandler.class)))
                .thenReturn(mockResponse);
    }



    @Test
    void testFetchNewsFeed() {
        NewsRequest mockRequest = mock(NewsRequest.class);

        when(mockRequest.getUri()).thenReturn(URI.create("https://example.com/api/news"));
        when(mockRequest.getUriQuery()).thenReturn("query=world&pageSize=10&page=1");

        List<String> expectedHeadlines = List.of("Breaking News 1", "Breaking News 2", "Breaking News 3");
        List<String> actualHeadlines = new ArrayList<>();

        try {
            actualHeadlines = testedFetcher.fetchNewsFeed(mockRequest).stream()
                    .map(Article::title)
                    .toList();
        } catch (Exception e) {
            fail("Exception thrown during fetchNewsFeed test: " + e.getMessage());
        }

        assertTrue(expectedHeadlines.containsAll(actualHeadlines) &&
                        actualHeadlines.containsAll(expectedHeadlines),
                "The fetched article headlines do not match the expected headlines.");
    }

    @Test
    void testFetchWithCachedRequest() {
        NewsRequest mockRequest = mock(NewsRequest.class);
        when(mockRequest.getUri()).thenReturn(URI.create("https://example.com/api/news"));
        when(mockRequest.getUriQuery()).thenReturn("query=world&pageSize=10&page=1");

        try {
            List<Article> firstFetch = testedFetcher.fetchNewsFeed(mockRequest);
            List<Article> secondFetch = testedFetcher.fetchNewsFeed(mockRequest);

            assertEquals(firstFetch, secondFetch, "The second fetch did not return the cached response.");
            verify(mockHttpClient, times(1))
                    .sendAsync(any(HttpRequest.class), any(HttpResponse.BodyHandler.class));
        } catch (Exception e) {
            fail("Exception thrown during caching test: " + e.getMessage());
        }
    }

    @Test
    void testFetchWithInvalidRequest() {
        assertThrows(InvalidRequestParameterException.class, () -> {
            testedFetcher.fetchNewsFeed(null);
        }, "Fetching with a null request did not throw InvalidRequestParameterException.");
    }
}
