package bg.sofia.uni.fmi.mjt.article;

public record Source(String id, String name) {

}
