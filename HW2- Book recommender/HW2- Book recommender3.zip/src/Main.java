import bg.sofia.uni.fmi.mjt.goodreads.book.Book;
import bg.sofia.uni.fmi.mjt.goodreads.tokenizer.TextTokenizer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.StringReader;
import java.util.List;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws FileNotFoundException {

        //text tokenizer check


        //Book::of check
        /*String [] tokens = {"0", "To Kill a Mockingbird", "Harper Lee",
                "\"The unforgettable novel of a childhood in a sleepy Southern town " +
                        "and the crisis of conscience that rocked it.\"",
                "\"['Classics', 'Fiction', 'Historical Fiction', 'School', 'Literature', 'Young Adult', 'Historical']\"",
                "4.27" ,"5,691,311", "https://www.goodreads.com/book/show/2657.To_Kill_a_Mockingbird" };

        Book newBook = Book.of(tokens);

        System.out.println(newBook.ID());
        System.out.println(newBook.author());
        System.out.println(newBook.description());

        for (String genre: newBook.genres()) {
            System.out.println(genre);
        }
        System.out.println(newBook.rating());
        System.out.println(newBook.ratingCount());
        System.out.println(newBook.URL());*/

       /*String STOP_WORDS = """
                            a " + "one\\n" + "am\\n" + "are\\n" + "and\\n"
                             + "of\\n" + "the\\n"" + "in\\n" + "its\\n"
                              + "has\\n" + "her\\n" + "as\\n" + "own\\n""
                               + "most\\n"" + "this\\n"
            """;


       StringReader reader;
       TextTokenizer tokenizer;
        reader = new StringReader(STOP_WORDS);
        tokenizer = new TextTokenizer(reader);

        String description = "Since its immediate success in 1813, Pride and Prejudice, " +
                "has remained one of the most popular novels in the English language. The " +
                "author- Jane Austen- called this brilliant work \"her own darling child\".";

        List<String> result =  tokenizer.tokenize(description);

        for (String str: result) {
            System.out.println(str);
        }*/
    }
}