package bg.sofia.uni.fmi.mjt.goodreads.recommender.similaritycalculator.genres;

import bg.sofia.uni.fmi.mjt.goodreads.book.Book;
import bg.sofia.uni.fmi.mjt.goodreads.recommender.similaritycalculator.SimilarityCalculator;

import java.util.HashSet;
import java.util.Set;

public class GenresOverlapSimilarityCalculator implements SimilarityCalculator {

    /**
     * Calculates the similarity between two books.
     *
     * @param first, second - Books used for similarity calculation
     * @throws IllegalArgumentException if first or second is null
     * @return a double - score of similarity
     */
    @Override
    public double calculateSimilarity(Book first, Book second) { //to check whether
        if (first == null || second == null) {
            throw new IllegalArgumentException("Books passed for " +
                    "comparison must not be null!");
        }
        if (first.genres().isEmpty() || second.genres().isEmpty()) {   //just a sample return value; I may change it later
            return 1;
        }

        Set<String> firstGenres = new HashSet<>(first.genres());
        Set<String> secondGenres = new HashSet<>(second.genres());
        int minSize = Math.min(firstGenres.size(), secondGenres.size());
        firstGenres.retainAll(secondGenres);
        return (double) firstGenres.size() /minSize;   //to do it without casting!
    }

}