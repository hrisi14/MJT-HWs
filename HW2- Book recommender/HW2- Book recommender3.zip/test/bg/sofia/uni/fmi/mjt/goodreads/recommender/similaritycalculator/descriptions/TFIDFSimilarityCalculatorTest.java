package bg.sofia.uni.fmi.mjt.goodreads.recommender.similaritycalculator.descriptions;

public class TFIDFSimilarityCalculatorTest {
}
