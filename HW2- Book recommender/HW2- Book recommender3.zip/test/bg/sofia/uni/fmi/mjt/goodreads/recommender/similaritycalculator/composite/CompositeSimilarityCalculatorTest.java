package bg.sofia.uni.fmi.mjt.goodreads.recommender.similaritycalculator.composite;

public class CompositeSimilarityCalculatorTest {
}
