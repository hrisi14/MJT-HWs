package bg.sofia.uni.fmi.mjt.goodreads.recommender;

public class BookRecommenderTest {
}
